# Website Sejarah Teknologi
Website yang menyediakan berbagai sejarah teknologi dan informasi untuk dibaca oleh pengguna.

### website
 https://st.ammarbahtiar.com

### Dev by me
 - Ahmad Ammar Bahtiar
 - ammarbahtiarasli#gmail.com
 - More about me https://me.ammarbahtiar.com

### Spesial thanks
 Dosen Pak Sandhika Galih dan Mentor Kang Rifki Gema fauzi yang sudah membimbing saya.
