<script src="https://cdn.ckeditor.com/ckeditor5/34.1.0/classic/ckeditor.js"></script>
<script>
    ClassicEditor
        .create(document.querySelector('#text-editor'))
        .catch(error => {
            console.error(error);
        });
</script>

<script src="./js/myscript.js"></script>
</body>

<!-- Bootstrap js -->
<script src="./js/bootstrap.bundle.min.js"></script>

<!-- Custom js -->
<script src="./js/script.js?v=1.0"></script>

</html>
